
stampEngine flags:
	b			borderless
	v			vsync
	d			debug
	
example command for borderless vsync:
"StampEngine.exe" -bv